def print_something_from_Train(test:str):
    print(test)